# LootValueNP

An SPT 4.0 port of [LootValue](https://github.com/IhanaMies/LootValue) by IhanaMies.

Shows item values directly in the tooltip (best trader price and/or lowest flea price) and adds quick-sell hotkeys.

- **Client plugin:** `BepInEx/plugins/Oryzaki-LootValueNP.dll`
- **Server mod:** `SPT/user/mods/Oryzaki-LootValueNP/` (C# server mod, required for flea prices)

## Requirements

- SPT 4.0+ (built and tested against SPT 4.0.13)

## Installation

1. Download and extract the archive into your SPT root folder (the folder that contains `EscapeFromTarkov.exe`).
   - `BepInEx/plugins/Oryzaki-LootValueNP.dll` → client plugin
   - `SPT/user/mods/Oryzaki-LootValueNP/` → server mod
2. Start the SPT server, then launch the game.

## Usage

- Hover an examined item in your stash to see its value appended to the tooltip:
  - The best trader buy price (client-side).
  - The lowest flea market price (fetched from the server; shown when flea access is available, or always if the option below is enabled).
- **Quick-sell** (default hotkey `LeftAlt + LeftShift`):
  - `LeftClick` → sell to the best-paying trader.
  - `RightClick` → sell to the flea market.
- Configure via **F12 → Configuration Manager**, or `BepInEx/config/Oryzaki-LootValueNP.cfg`.

Notable options:

| Option | Default | Effect |
|---|---|---|
| Enable quick selling | true | Enables the quick-sell hotkeys |
| Enable quick selling to flea | true | Enables the flea quick-sell path |
| One button quick sell | false | LMB sells to flea then falls back to trader |
| Show flea price before having access to flea (character level 15) | false | Show flea prices in the tooltip even without flea access |
| Show prices | true | Show value text in the item tooltip |
| Traders to ignore | (empty) | Comma-separated trader ids to skip |

## Credits

Based on [LootValue](https://github.com/IhanaMies/LootValue) by **IhanaMies (Mikael Palokangas)**, MIT licensed.
This version is an SPT 4.0 port with the server backend rewritten in C# and a non-blocking price-fetch fix.

## License

[MIT](LICENSE) — Copyright (c) 2024 Mikael Palokangas aka IhanaMies, Copyright (c) 2026 Oryzaki.
